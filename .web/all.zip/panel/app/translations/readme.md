# About Panel translations

Panel translations are managed at [Transifex](https://www.transifex.com/getkirby/panel). Changes at Transifex are used in this repository.
If you'd like to contribute (thank you!), please request access to your language at Transifex.

Read more in the [Kirby docs](https://getkirby.com/docs/developer-guide/panel/translations).