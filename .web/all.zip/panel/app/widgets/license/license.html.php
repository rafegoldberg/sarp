<style>
.dashboard-license-box a {
  font-weight: 600;
  white-space: nowrap;
}
.dashboard-license-box a:after {
  content: "›";
  padding-left: .25em;
}
</style>
<div class="dashboard-box dashboard-license-box">
  <div class="text">
    <?php echo $text ?>
  </div>
</div>