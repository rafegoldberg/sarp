<?php 

class APage extends Page {

  public function customTestMethod() {
    return 'test';
  }

}